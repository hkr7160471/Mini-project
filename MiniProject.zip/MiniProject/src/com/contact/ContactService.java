package com.contact;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.Consumes;
 

 

@Path("/ContactService")
public class ContactService {

    // URI:
    // /contextPath/servletPath/employees
    @GET
    @Path("/getContacts")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Contact> getContacts_JSON() {
    	
    	List<Contact> listOfContacts = ContactDAO.getAllContacts();//getAllEmployees();
        return listOfContacts;
    }
    
    // URI:
    // /contextPath/servletPath/employees/{empNo}
    @GET
	@Path("/getContact/{firstName}")
	@Produces(MediaType.APPLICATION_JSON)
	public Contact getContact(@PathParam("FirstName") String FirstName) {
    	
        return ContactDAO.getFirstName(FirstName);//getEmployee(empNo);
    }   
    
    // URI:
    // /contextPath/servletPath/employees
    @POST
    @Path("/addContact")
	@Consumes(MediaType.APPLICATION_JSON)
	public Contact addContact(Contact c) {
    	return ContactDAO.addContact(c);
    }

    @PUT
    @Path("/updateContact")
	@Consumes(MediaType.APPLICATION_JSON)
    public Contact updateContact(Contact c) {
        return ContactDAO.updateContact(c);
    }
    
    @DELETE
    @Path("/deleteContact/{firstName}")
	@Produces(MediaType.APPLICATION_JSON)
    public void deleteContact(@PathParam("FirstName") String FirstName) {
    	
    	ContactDAO.deleteContact(FirstName);//deleteEmployee(empNo);
    }
}

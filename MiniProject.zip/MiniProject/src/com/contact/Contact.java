package com.contact;

import javax.xml.bind.annotation.XmlElement;


 
public class Contact {
 
    private String firstName;
    private String lastName;
    private String contactNumber;
 
    // This default constructor is required if there are other constructors.
    public Contact() {
 
    }
 
    public Contact(String firstName, String lastName, String contactNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNumber = contactNumber;
    }
 
    public String getFirstName () {
        return firstName;
    }
         @XmlElement
    public void setFirstName (String firstName) {
        this.firstName = firstName;
    }
 
    public String getLastName () {
        return lastName;
    }
              @XmlElement

    public void setLastName (String lastName) {
        this.lastName = lastName;
    }
 
    public String getContactNumber () {
        return contactNumber;
    }
          @XmlElement

    public void setContactNumber (String contactNumber) {
        this.contactNumber = contactNumber;
    }
 
}